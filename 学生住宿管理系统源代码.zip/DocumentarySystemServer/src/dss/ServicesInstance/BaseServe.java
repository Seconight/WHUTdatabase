package dss.ServicesInstance;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class BaseServe {
	
	
	
	
	
}
